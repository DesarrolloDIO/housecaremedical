<x-guest-layout>

    <div class="container mx-auto pt-4">

        <div class="mb-6">

        </div>

    </div>
</x-guest-layout>
